package tests;

import static org.junit.Assert.*;

import org.junit.Test;

/**
 * 
 * You need student tests if you are looking for help during office hours about
 * bugs in your code.
 * 
 * @author UMCP CS Department
 *
 */
public class StudentTests {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
