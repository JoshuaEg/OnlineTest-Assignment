package onlineTest;

import java.util.ArrayList;
import java.util.Collections;

public class FillBlank extends Question{
	
String[] answer;
	
	public FillBlank(String text, double points, String[] answer) {
		super(text, points);
		 this.answer = answer;
	}
	
	public double earnPoints(String[] sAnswer) {
		int correct = 0;
		for(int i = 0; i < answer.length; i++) {
			for(int j = 0; j < sAnswer.length; j++) {
				if(answer[i].equals(sAnswer[j])) {
					correct++;
				}
			}
		}
		
		return points * ((double)correct/(double)answer.length);
	}

	
	public String getKey() {
		ArrayList<String> list = new ArrayList<>();
		
		for(String s : answer) {
			list.add(s);
		}
		
		Collections.sort(list);
		String key = "Question Text: " + text;
		key += "\nPoints: " + points;
		key += "Correct Answer: " +  list;
		return key;
	}
}
