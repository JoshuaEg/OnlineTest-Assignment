package onlineTest;


import java.io.Serializable;
import java.util.TreeMap;

public class Exam implements Serializable {
	private static final long serialVersionUID = 1L;
	String name;
	//int id; Make a map with the id in the manager
	TreeMap<Integer, Question> questions; //Change to a map with the num
	double totalPoints;
	
	public Exam(String name) {
		this.name = name;
		//this.id = id;
		questions = new TreeMap<>();
		totalPoints = 0;
	}
	
	public double getPoints() {
		return totalPoints;
	}
	
	public Question getQuestion(int num) {
		return questions.get(num);
	}
	
	protected TreeMap<Integer, Question> getQuestions(){
		return questions;
	}
	
	public void addQuestion(Question q, int num) {
		questions.put(num, q);
		totalPoints += q.points;
	}
	      
	public String getKey() {
		String key = "";
		for(Question q : questions.values()) {
			key += q.getKey();
			key += "\n";
		}
		
		return key;
	}
	
	
	
}
