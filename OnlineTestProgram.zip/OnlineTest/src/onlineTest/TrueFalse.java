package onlineTest;

public class TrueFalse extends Question {
	boolean answer;
	
	public TrueFalse(String text, double points, boolean answer){
		super(text, points);
		this.answer = answer;
	}
	

	
	public double earnPoints(boolean answer) {
		if(this.answer == answer) {
			return points;
		}
		return 0;
	}

	public String getKey() {
		String ans =   answer ? "True" : "False";
		String key = "Question Text: " + text;
		key += "\nPoints: " + points;
		key += "\nCorrect Answer: " + ans;
		return key;
		
	}

}
