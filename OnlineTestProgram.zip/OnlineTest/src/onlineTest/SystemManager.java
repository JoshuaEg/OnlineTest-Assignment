package onlineTest;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InvalidClassException;
import java.io.NotSerializableException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.TreeMap;



public class SystemManager implements Manager, Serializable {
	
	private static final long serialVersionUID = 1L;
	TreeMap<Integer, Exam> exams;
	String[] letterGrades;
	double[] cutoffs;
	
	class Student implements Serializable {
		
		private static final long serialVersionUID = 1L;
		
		String name;
		TreeMap<Integer, TreeMap<Integer, Double>> scores;
		TreeMap<Integer, Double> examScores;
		
		public Student(String name) {
			this.name = name;
			scores = new TreeMap<>();
			examScores = new TreeMap<>();
		}
		
		public void putExam(int id) {
			scores.put(id, new TreeMap<Integer, Double>());
		}
		
		private void answerMultiChoice(int examId, int num, String[] answer) {
			
			double score = ((MultipleChoice)exams.get(examId).getQuestion(num)).earnPoints(answer);
			scores.get(examId).put(num, score);
			
			putScore(examId);
			
		}
		
		private void answerFillBlank(int examId, int num, String[] answer) {
			
			double score = ((FillBlank)exams.get(examId).getQuestion(num)).earnPoints(answer);
			scores.get(examId).put(num, score);
			
			putScore(examId);
			
		}
		
		private void answerBoolean(int examId, int num, Boolean answer) {
			
			double score = ((TrueFalse)exams.get(examId).getQuestion(num)).earnPoints(answer);
			scores.get(examId).put(num, score);
			
			putScore(examId);
		}
		
		private double examResult(int id) {
			double result = 0;
			for(double i : scores.get(id).values()) {
				result += i;
			}
			return result;
		}
		
		private double getResult(int examid,int num) {
			return scores.get(examid).get(num);
		}
		
		private void putScore(int id) {
			examScores.put(id, examResult(id));
		}
		
	}
	
	TreeMap<String, Student> students;
	
	public SystemManager() {
		exams = new TreeMap<>();
		students = new TreeMap<>();
	}
	
	public boolean addExam(int examId, String title) {
		if (exams.keySet().contains(examId)) return false;
		exams.put(examId, new Exam(title));
		
		for(Student s : students.values()) {
			s.putExam(examId);
		}
		
		return true;
	}
	
    public void addTrueFalseQuestion(int examId, int questionNumber,
		    String text, double points, boolean answer) {
    	
    	exams.get(examId).addQuestion(new TrueFalse(text,points,answer), questionNumber);
    }
    
    public void addMultipleChoiceQuestion(int examId, int questionNumber,
		    String text, double points, String[] answer) {
    	
    	exams.get(examId).addQuestion(new MultipleChoice(text, points, answer), questionNumber);
    }
    
    public void addFillInTheBlanksQuestion(int examId, int questionNumber,
		    String text, double points, String[] answer) {
    	
    	exams.get(examId).addQuestion(new FillBlank(text,points,answer), questionNumber);
    }
    
    
    public String getKey(int examId) {
    	if(exams.get(examId) == null) return "Exam not found";
    	return exams.get(examId).getKey();
    }

    public boolean addStudent(String name) {
    	if(students.keySet().contains(name)) return false;
    	Student s = new Student(name);
    	students.put(name, s);
    	
    	for(int i : exams.keySet()) {
    		s.putExam(i);
    	}
    	
    	return true;
    }
    
    public void answerTrueFalseQuestion(String studentName, int examId, int questionNumber, boolean answer) {
    	students.get(studentName).answerBoolean(examId, questionNumber, answer);
    }
    
    public void answerMultipleChoiceQuestion(String studentName, int examId, int questionNumber, String[] answer) {
    	students.get(studentName).answerMultiChoice(examId, questionNumber, answer);
    }
    
    public void answerFillInTheBlanksQuestion(String studentName, int examId, int questionNumber, String[] answer) {
    	students.get(studentName).answerFillBlank(examId, questionNumber, answer);
    }

    
   
    public double getExamScore(String studentName, int examId) {
    	return students.get(studentName).examResult(examId);
    }
	
    public String getGradingReport(String studentName, int examId) {
    	Exam exam = exams.get(examId);
    	Student student = students.get(studentName);
    	String report =  "";
    	for(int num : exam.getQuestions().keySet()) {
    		report += "Question #" + num + " " + student.getResult(examId, num) + 
    				" points out of " + exam.getQuestion(num).points + "\n";
    		
    	}
    	report += "Final Score: " + student.examResult(examId) + " out of " + exam.totalPoints; 
    	return report;
    }
    
    public void setLetterGradesCutoffs(String[] letterGrades, double[] cutoffs) {
    	this.letterGrades = letterGrades;
    	this.cutoffs = cutoffs;
    	
    }
    
    
    public double getCourseNumericGrade(String studentName) {
    	Student s = students.get(studentName);
    	ArrayList<Double> results = new ArrayList<>();
    	double total = 0;
    	double result = 0;
    	for(int e : exams.keySet()) {
    		//for(double r : s.examScores.values()) {
    			total = exams.get(e).getPoints();
        		result = s.examResult(e);
        		
        		results.add((result/total)*100d);
        	//}
    	}
    	
    	double sum = 0;
    	for(double d : results) {
    		sum += d;
    	}
    	
    	return sum/(double) results.size();
    }
    
    public String getCourseLetterGrade(String studentName) {
    	double grade = getCourseNumericGrade(studentName);
    	
    	for(int i = 0; i < letterGrades.length; i++) {
    		if(grade >= cutoffs[i]) return letterGrades[i];
    	}
    	
    	return null;
    }
    
    public String getCourseGrades() {
    	String result = "";
    	
    	for(Student s : students.values()) {
    		result += s.name + " " + getCourseNumericGrade(s.name)
    			+ getCourseLetterGrade(s.name) + "\n";
    	}
    	
    	return result;
    }
    
    public double getMaxScore(int examId) {
    	ArrayList<Double> list = new ArrayList<>();
    	
    	for(Student s : students.values()) {
    		list.add(s.examScores.get(examId));
    	}
    	Collections.sort(list);
    	
    	return list.get(list.size()-1);
    }
    
    public double getMinScore(int examId) {
    	ArrayList<Double> list = new ArrayList<>();
    	
    	for(Student s : students.values()) {
    		list.add(s.examScores.get(examId));
    	}
    	Collections.sort(list);
    	
    	return list.get(0);
    	
    }
    
    public double getAverageScore(int examId) {
    	double scores = 0;
    	int count = 0;
    	
    	for(Student s : students.values()) {
    		scores += s.examScores.get(examId);
    		count++;
    	}
    	
    	return scores/(double)count;
    }
        
	public void saveManager(Manager manager, String fileName) {
		File file = new  File(fileName);
		try {
		ObjectOutputStream output = new ObjectOutputStream(new FileOutputStream(file));

		output.writeObject((SystemManager)manager);
		
		
		output.close();
		} catch (IOException e) {
			System.err.print(e.getMessage());
			return;
		}
		
		
	}
    
	public Manager restoreManager(String fileName) {
		File file = new File(fileName);

		if (!file.exists()) {
			return new SystemManager();
		} else {
			try {
			ObjectInputStream input = new ObjectInputStream(new FileInputStream(file));
			SystemManager manager = (SystemManager) input.readObject();
			input.close();
			return manager;
			} catch(Exception e) {
				return new SystemManager();
			}
		} 
	}
    
    
}    
