package onlineTest;

import java.util.ArrayList;
import java.util.Collections;

public class MultipleChoice extends Question {

	String[] answer;
	
	public MultipleChoice(String text, double points, String[] answer) {
		super(text, points);
		 this.answer = answer;
	}
	
	@Override
	public double earnPoints(String[] sAnswer) {
		int correct = 0;
		for(int i = 0; i < answer.length; i++) {
			for(int j = 0; j < sAnswer.length; j++) {
				if(answer[i].equals(sAnswer[j])) {
					correct++;
				}
			}
		}
		if(correct != answer.length) {
			return 0;
		}
		
		if(sAnswer.length != answer.length) {
			return 0;
		}
		
		return points;
	}
	
	public String getKey() {
		ArrayList<String> list = new ArrayList<>();
		
		for(String s : answer) {
			list.add(s);
		}
		
		Collections.sort(list);
		String key = "Question Text: " + text;
		key += "\nPoints: " + points;
		key += "Correct Answer: " +  list;
		return key;
	}
	
}
