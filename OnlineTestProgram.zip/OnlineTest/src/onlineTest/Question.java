package onlineTest;

import java.io.Serializable;

public abstract class Question implements Serializable {
	private static final long serialVersionUID = 1L;
	
	String text;
	double points;
	
	public Question(String text, double points) {
		
		this.text = text;
		this.points = points;
	}
	
	
	
	public String getText() {
		return text;
	}
	
	
	public double earnPoints(String[] ans) {
		throw new UnsupportedOperationException("Specify Question");
	}
	
	public double earnPoints(boolean ans) {
		throw new UnsupportedOperationException("Specify Question");
	}
	
	public abstract String getKey();
	

	
}
